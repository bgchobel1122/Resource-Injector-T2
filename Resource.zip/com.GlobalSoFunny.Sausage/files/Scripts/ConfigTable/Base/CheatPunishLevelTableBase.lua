



local CheatPunishLevelTableBase = 



return CheatPunishLevelTableBase